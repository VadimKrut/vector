#ifndef GET_CORE_ID_H
#define GET_CORE_ID_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

    uint32_t get_core_id();

#ifdef __cplusplus
}
#endif

#endif