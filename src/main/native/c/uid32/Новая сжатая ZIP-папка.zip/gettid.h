#ifndef GETTID_H
#define GETTID_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

    uint32_t gettid();

#ifdef __cplusplus
}
#endif

#endif