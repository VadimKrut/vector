#ifndef UID32_H
#define UID32_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

    const uint8_t* generate_uid32();

#ifdef __cplusplus
}
#endif

#endif